\c it4med it4med

create table it4med.MKB_BUFF( ACTUAL      numeric(1), 
                              ADDL_CODE   varchar(64),
                              DATE        varchar(16),
                              ID_PARENT   numeric(17),
                              MKB_CODE    varchar(512),
                              MKB_NAME    varchar(512),
                              REC_CODE    varchar(64),
                              ID          numeric(17)
);

\COPY it4med.MKB_BUFF FROM '/docker-entrypoint-initdb.d/csv/1.2.643.5.1.13.13.11.1005_2.24.csv' DELIMITER ';' CSV HEADER;

insert into it4med.MKB (OID, PARENT_OID, REC_CODE, MKB_CODE, MKB_NAME, ADDL_CODE, ACTUAL, ACTUAL_DATE) 
  select id, id_parent, rec_code, mkb_code, mkb_name, addl_code, actual, to_date(date, 'DD.MM.YYYY') from it4med.mkb_buff;

drop table it4med.MKB_BUFF;

create table it4med.MEDP_BUFF (        
	CODE_ATC            VARCHAR(64),
	COMPLETENESS        VARCHAR(256), 
	COUNTRY             VARCHAR(64),
	DATE_REGISTRATION   VARCHAR(16),
	ESSENTIAL_MEDICINES VARCHAR(32),
	KLP_CODE            VARCHAR(64),
	KTRU_CODE           VARCHAR(64),
	NAME_1_PACKING      VARCHAR(160),
	NAME_2_PACKAGE      VARCHAR(64),
	NAME_ATC            VARCHAR(512),
	NAME_PRODUCER       VARCHAR(256),
	NAME_TRADE          VARCHAR(512),
	NAME_UNIT           VARCHAR(64),
	NARCOTIC_PSYCHOTROPIC VARCHAR(32),
	NORMALIZED_DOSAGE   VARCHAR(160),
	NORMALIZED_FORM     VARCHAR(160),
	NUMBER_PACKAGES     NUMERIC(17),
	NUMBER_REGISTRATION VARCHAR(64),
	NUMBER_UNITS_1      VARCHAR(32),
	NUMBER_UNITS_2      VARCHAR(32),
	OKEI_CODE           VARCHAR(16),
	OKPD_2_CODE         VARCHAR(32),
	OKSM_CODE           VARCHAR(16),
	SMNN_CODE           VARCHAR(64),
	STANDARD_DOZE       VARCHAR(160),
	STANDARD_FORM       VARCHAR(160),
	STANDARD_INN        VARCHAR(1024),
	TN                  VARCHAR(256),
	ID                  NUMERIC(17)
);

\COPY it4med.MEDP_BUFF FROM '/docker-entrypoint-initdb.d/csv/1.2.643.5.1.13.13.99.2.540_9.206.csv' DELIMITER ';' CSV HEADER;

insert into it4med.MEDP(CODE_ATC,COMPLETENESS,COUNTRY,DATE_REGISTRATION,ESSENTIAL_MEDICINES,KLP_CODE,KTRU_CODE,NAME_1_PACKING,NAME_2_PACKAGE,NAME_ATC,NAME_PRODUCER,NAME_TRADE,NAME_UNIT,NARCOTIC_PSYCHOTROPIC,NORMALIZED_DOSAGE,NORMALIZED_FORM,NUMBER_PACKAGES,NUMBER_REGISTRATION,NUMBER_UNITS_1,NUMBER_UNITS_2,OKEI_CODE,OKPD_2_CODE,OKSM_CODE,SMNN_CODE,STANDARD_DOZE,STANDARD_FORM,STANDARD_INN,TN,ID) 
  select CODE_ATC,COMPLETENESS,COUNTRY,to_date(DATE_REGISTRATION, 'DD.MM.YYYY'),ESSENTIAL_MEDICINES,KLP_CODE,KTRU_CODE,NAME_1_PACKING,NAME_2_PACKAGE,NAME_ATC,NAME_PRODUCER,NAME_TRADE,NAME_UNIT,NARCOTIC_PSYCHOTROPIC,NORMALIZED_DOSAGE,NORMALIZED_FORM,NUMBER_PACKAGES,NUMBER_REGISTRATION,NUMBER_UNITS_1,NUMBER_UNITS_2,OKEI_CODE,OKPD_2_CODE,OKSM_CODE,SMNN_CODE,STANDARD_DOZE,STANDARD_FORM,STANDARD_INN,TN,ID from it4med.MEDP_BUFF;

drop table it4med.MEDP_BUFF;


create table it4med.MEDUS_BUFF (
   DATEOUT     varchar(16),
   NAME        varchar(512),
   REL         numeric(1),
   S_CODE      varchar(32),
   ID          numeric(17)
);


\COPY it4med.MEDUS_BUFF FROM '/docker-entrypoint-initdb.d/csv/1.2.643.5.1.13.13.11.1070_2.10.csv' DELIMITER ';' CSV HEADER;


insert into it4med.MEDUS (DATEOUT, NAME, REL, S_CODE, ID) 
  select to_date(DATEOUT, 'DD.MM.YYYY'), NAME, REL, S_CODE, ID from MEDUS_BUFF;

drop table  it4med.MEDUS_BUFF;

create table it4med.MEDP_IN_BUFF (
   NAME_ENG             VARCHAR(64)          null,
   NAME_RUS             VARCHAR(64)          null,
   NSI_CODE_EEC         VARCHAR(64)          null,
   NSI_ELEMENT_CODE_ECC VARCHAR(64)          null,
   PARENT              NUMERIC(17)          null,
   ID                   NUMERIC(17)          not null
);


\COPY it4med.MEDP_IN_BUFF FROM '/docker-entrypoint-initdb.d/csv/1.2.643.5.1.13.13.11.1468_2.3.csv' DELIMITER ';' CSV HEADER;

insert into it4med.MEDP_IN (ID, PARENT_ID, NAME_ENG, NAME_RUS, NSI_CODE_EEC, NSI_ELEMENT_CODE_ECC)
  select ID, PARENT, NAME_ENG, NAME_RUS, NSI_CODE_EEC, NSI_ELEMENT_CODE_ECC from it4med.MEDP_IN_BUFF;

drop table it4med.MEDP_IN_BUFF;

SET datestyle = "ISO, DMY";

\COPY it4med.PERSON FROM '/docker-entrypoint-initdb.d/csv/random_person.csv' DELIMITER ',' CSV HEADER encoding 'windows-1251';
\COPY it4med.DOCTOR FROM '/docker-entrypoint-initdb.d/csv/random_doctor.csv' DELIMITER ',' CSV HEADER encoding 'windows-1251';

