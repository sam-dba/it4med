create user it4med with createdb login password 'it4med';
grant pg_read_server_files to it4med;
create database it4med with owner = it4med;



