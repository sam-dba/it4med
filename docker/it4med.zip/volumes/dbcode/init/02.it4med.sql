\c it4med it4med
CREATE SCHEMA IF NOT EXISTS it4med AUTHORIZATION it4med;

/*==============================================================*/
/* Table: DOCTOR                                                */
/*==============================================================*/
create table it4med.DOCTOR (
   ID                   NUMERIC(17)          not null,
   SPECZ                VARCHAR(64)          not null,
   POST                 VARCHAR(64)          not null,
   JOBBEGIN_DATE        date                 not null,
   DISMISS_DATE         date                 null,
   constraint PK_DOCTOR primary key (ID)
);

/*==============================================================*/
/* Index: DOCTOR_PK                                             */
/*==============================================================*/
create unique index DOCTOR_PK on DOCTOR (
ID
);

/*==============================================================*/
/* Table: EMR                                                   */
/*==============================================================*/
create table it4med.EMR (
   ID                   NUMERIC(17)          not null,
   PERSON_ID            NUMERIC(17)          not null,
   DOCTOR_ID            NUMERIC(17)          not null,
   IN_DATE              DATE                 not null,
   OUT_DATE             DATE                 null,
   constraint PK_EMR primary key (ID)
);

/*==============================================================*/
/* Index: EMR_PK                                                */
/*==============================================================*/
create unique index EMR_PK on EMR (
ID
);

/*==============================================================*/
/* Index: DOCTOR__EMR_FK                                        */
/*==============================================================*/
create  index DOCTOR__EMR_FK on EMR (
DOCTOR_ID
);

/*==============================================================*/
/* Index: PERSON__EMR_FK                                        */
/*==============================================================*/
create  index PERSON__EMR_FK on EMR (
PERSON_ID
);

/*==============================================================*/
/* Table: EMR_MED                                               */
/*==============================================================*/
create table it4med.EMR_MED (
   ID                   NUMERIC(17)          not null,
   MEDP_IN_ID           NUMERIC(17)          not null,
   EMR_ID               NUMERIC(17)          not null,
   MEDP_ID              NUMERIC(17)          not null,
   DATE_BEG             DATE                 not null,
   DATE_END             DATE                 null,
   constraint PK_EMR_MED primary key (ID)
);

/*==============================================================*/
/* Index: EMR_MED_PK                                            */
/*==============================================================*/
create unique index EMR_MED_PK on EMR_MED (
ID
);

/*==============================================================*/
/* Index: MEDP__EMR_MED_FK                                      */
/*==============================================================*/
create  index MEDP__EMR_MED_FK on EMR_MED (
MEDP_ID
);

/*==============================================================*/
/* Index: MEDP_IN__MEDP_IN_FK                                   */
/*==============================================================*/
create  index MEDP_IN__MEDP_IN_FK on EMR_MED (
MEDP_IN_ID
);

/*==============================================================*/
/* Index: EMR__EMR_MED_FK                                       */
/*==============================================================*/
create  index EMR__EMR_MED_FK on EMR_MED (
EMR_ID
);

/*==============================================================*/
/* Table: EMR_MKB                                               */
/*==============================================================*/
create table it4med.EMR_MKB (
   OID                  NUMERIC(5)          not null,
   ID                   NUMERIC(17)         not null,
   INDATE               date                not null,
   OUDATE               date                null,
   constraint PK_EMR_MKB primary key (OID, ID)
);

/*==============================================================*/
/* Index: EMR_MKB_PK                                            */
/*==============================================================*/
create unique index EMR_MKB_PK on EMR_MKB (
OID,
ID
);

/*==============================================================*/
/* Index: EMR_MKB_FK                                            */
/*==============================================================*/
create  index EMR_MKB_FK on EMR_MKB (
OID
);

/*==============================================================*/
/* Index: EMR_MKB2_FK                                           */
/*==============================================================*/
create  index EMR_MKB2_FK on EMR_MKB (
ID
);

/*==============================================================*/
/* Table: EMR_SERV                                              */
/*==============================================================*/
create table it4med.EMR_SERV (
   ID                   NUMERIC(17)          not null,
   EMR_ID               NUMERIC(17)          not null,
   MEDUS_ID             NUMERIC(17)          not null,
   DOCTOR_ID            NUMERIC(17)          not null,
   SERV_DATE            DATE                 not null,
   constraint PK_EMR_SERV primary key (ID)
);

/*==============================================================*/
/* Index: EMR_SERV_PK                                           */
/*==============================================================*/
create unique index EMR_SERV_PK on EMR_SERV (
ID
);

/*==============================================================*/
/* Index: MEDUS__EMR_SERV_FK                                    */
/*==============================================================*/
create  index MEDUS__EMR_SERV_FK on EMR_SERV (
MEDUS_ID
);

/*==============================================================*/
/* Index: DOCTOR__EMR_SERV_FK                                   */
/*==============================================================*/
create  index DOCTOR__EMR_SERV_FK on EMR_SERV (
DOCTOR_ID
);

/*==============================================================*/
/* Index: EMR__EMR_SERV_FK                                      */
/*==============================================================*/
create  index EMR__EMR_SERV_FK on EMR_SERV (
EMR_ID
);

/*==============================================================*/
/* Table: MEDP                                                  */
/*==============================================================*/
create table it4med.MEDP (
   ID                   NUMERIC(17)          not null,
   KLP_CODE             VARCHAR(64)          null,
   SMNN_CODE            VARCHAR(64)          null,
   KTRU_CODE            VARCHAR(64)          null,
   NAME_TRADE           VARCHAR(512)          null,
   STANDARD_INN         VARCHAR(1024)          null,
   STANDARD_FORM        VARCHAR(160)          null,
   STANDARD_DOZE        VARCHAR(160)          null,
   NAME_PRODUCER        VARCHAR(256)          null,
   OKSM_CODE            VARCHAR(16)          null,
   COUNTRY              VARCHAR(64)          null,
   NUMBER_REGISTRATION  VARCHAR(64)          null,
   DATE_REGISTRATION    DATE                 null,
   NAME_UNIT            VARCHAR(64)          null,
   OKEI_CODE            VARCHAR(16)          null,
   NORMALIZED_DOSAGE    VARCHAR(160)          null,
   NORMALIZED_FORM      VARCHAR(160)          null,
   NAME_1_PACKING       VARCHAR(160)          null,
   NUMBER_UNITS_1       VARCHAR(32)          null,
   NAME_2_PACKAGE       VARCHAR(64)          null,
   NUMBER_PACKAGES      NUMERIC(17)          null,
   NUMBER_UNITS_2       VARCHAR(32)          null,
   OKPD_2_CODE          VARCHAR(32)          null,
   ESSENTIAL_MEDICINES  VARCHAR(32)          null,
   NARCOTIC_PSYCHOTROPIC VARCHAR(32)         null,
   CODE_ATC             VARCHAR(64)          null,
   NAME_ATC             VARCHAR(512)          null,
   TN                   VARCHAR(256)         null,
   COMPLETENESS         VARCHAR(256)          null,
   constraint PK_MEDP primary key (ID)
);

/*==============================================================*/
/* Index: MEDP_PK                                               */
/*==============================================================*/
create unique index MEDP_PK on MEDP (
ID
);

/*==============================================================*/
/* Table: MEDUS                                                 */
/*==============================================================*/
create table it4med.MEDUS (
   ID                   NUMERIC(17)          not null,
   S_CODE               VARCHAR(32)          null,
   NAME                 VARCHAR(512)         not null,
   REL                  NUMERIC(1)           null,
   DATEOUT              DATE                 null,
   constraint PK_MEDUS primary key (ID)
);

/*==============================================================*/
/* Index: MEDUS_PK                                              */
/*==============================================================*/
create unique index MEDUS_PK on MEDUS (
ID
);

/*==============================================================*/
/* Table: MEDP_IN                                               */
/*==============================================================*/
create table it4med.MEDP_IN (
   ID                   NUMERIC(17)          not null,
   PARENT_ID              NUMERIC(17)          null,
   NAME_RUS             VARCHAR(64)          null,
   NAME_ENG             VARCHAR(64)          null,
   NSI_CODE_EEC         VARCHAR(64)          null,
   NSI_ELEMENT_CODE_ECC VARCHAR(64)          null,
   constraint PK_MEDP_IN primary key (ID)
);

/*==============================================================*/
/* Index: MEDP_IN_PK                                            */
/*==============================================================*/
create unique index MEDP_IN_PK on MEDP_IN (
ID
);

/*==============================================================*/
/* Index: MEDP_IN_PARENT_FK                                     */
/*==============================================================*/
create  index MEDP_IN_PARENT_FK on MEDP_IN (
PARENT_ID
);

/*==============================================================*/
/* Table: MKB                                                   */
/*==============================================================*/
create table it4med.MKB (
   OID                  numeric(5)          not null,
   PARENT_OID           numeric(64)          null,
   REC_CODE             VARCHAR(16)          null,
   MKB_CODE             VARCHAR(16)         null,
   MKB_NAME             VARCHAR(512)         null,
   ADDL_CODE            VARCHAR(64)          null,
   ACTUAL               numeric(1)           null,
   ACTUAL_DATE          DATE                 null,
   constraint PK_MKB primary key (OID)
);

/*==============================================================*/
/* Index: MKB_PK                                                */
/*==============================================================*/
create unique index MKB_PK on MKB (
OID
);

/*==============================================================*/
/* Index: OID_PARENT_FK                                         */
/*==============================================================*/
create  index OID_PARENT_FK on MKB (
PARENT_OID
);

/*==============================================================*/
/* Table: PERSON                                                */
/*==============================================================*/
create table it4med.PERSON (
   ID                   NUMERIC(17)          not null,
   SNILS                VARCHAR(16)          not null,
   FAMILY               VARCHAR(64)          null,
   NAME                 VARCHAR(64)          null,
   LASTNAME             VARCHAR(64)          null,
   PERSBURN             DATE                 null,
   constraint PK_PERSON primary key (ID)
);

/*==============================================================*/
/* Index: PERSON_PK                                             */
/*==============================================================*/
create unique index PERSON_PK on PERSON (
ID
);

alter table DOCTOR
   add constraint FK_DOCTOR_PERSON__D_PERSON foreign key (ID)
      references PERSON (ID)
      on delete restrict on update restrict;

alter table EMR
   add constraint FK_EMR_DOCTOR__E_DOCTOR foreign key (DOCTOR_ID)
      references DOCTOR (ID)
      on delete restrict on update restrict;

alter table EMR
   add constraint FK_EMR_PERSON__E_PERSON foreign key (PERSON_ID)
      references PERSON (ID)
      on delete restrict on update restrict;

alter table EMR_MED
   add constraint FK_EMR_MED_EMR__EMR__EMR foreign key (EMR_ID)
      references EMR (ID)
      on delete restrict on update restrict;

alter table EMR_MED
   add constraint FK_EMR_MED_MEDP__EMR_MEDP foreign key (MEDP_ID)
      references MEDP (ID)
      on delete restrict on update restrict;

alter table EMR_MED
   add constraint FK_EMR_MED_MEDP_IN___MEDP_IN foreign key (MEDP_IN_ID)
      references MEDP_IN (ID)
      on delete restrict on update restrict;

alter table EMR_MKB
   add constraint FK_EMR_MKB_EMR_MKB_MKB foreign key (OID)
      references MKB (OID)
      on delete restrict on update restrict;

alter table EMR_MKB
   add constraint FK_EMR_MKB_EMR_MKB2_EMR foreign key (ID)
      references EMR (ID)
      on delete restrict on update restrict;

alter table EMR_SERV
   add constraint FK_EMR_SERV_DOCTOR__E_DOCTOR foreign key (DOCTOR_ID)
      references DOCTOR (ID)
      on delete restrict on update restrict;

alter table EMR_SERV
   add constraint FK_EMR_SERV_EMR__EMR__EMR foreign key (EMR_ID)
      references EMR (ID)
      on delete restrict on update restrict;

alter table EMR_SERV
   add constraint FK_EMR_SERV_MEDUS__EM_MEDUS foreign key (MEDUS_ID)
      references MEDUS (ID)
      on delete restrict on update restrict;

alter table MEDP_IN
   add constraint FK_MEDP_IN_MEDP_IN_P_MEDP_IN foreign key (PARENT_ID)
      references MEDP_IN (ID)
      on delete restrict on update restrict;

alter table MKB
   add constraint FK_MKB_OID_PAREN_MKB foreign key (PARENT_OID)
      references MKB (OID)
      on delete restrict on update restrict;

